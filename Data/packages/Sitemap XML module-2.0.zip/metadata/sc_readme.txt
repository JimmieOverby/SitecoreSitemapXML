After installation:
1) Perform publishing
2) Configure Sitemap XML using:
     Configuration item "/sitecore/system/Modules/Sitemap XML/Sitemap configuration":
     Configuration file "App_Config\Include\SitemapXML.xml"